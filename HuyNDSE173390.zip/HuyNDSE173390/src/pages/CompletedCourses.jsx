import React from 'react'

function CompletedCourses() {
  return (
    <div>CompletedCourses</div>
  )
}

export default CompletedCourses