import { useEffect, useState } from "react";
import { MainAPI } from "../MainAPI";
import { Button, Card, Col, Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import useAnimateOnScroll from "../hooks/useAnimateOnScroll";

export default function Home() {
  const [API, setAPI] = useState([]);
  const sectionRef = useAnimateOnScroll();

  useEffect(() => {
    const fetchAPI = async () => {
      await fetch(MainAPI, {
        method: "GET",
        headers: {
          "Content-type": "application/json",
        },
      })
        .then((response) => {
          if (!response.ok) throw new Error("Network response was not ok");
          return response.json();
        })
        .then((data) => setAPI(data))
        .catch((error) => console.log(error));
    };

    fetchAPI();
  }, []);

  useEffect(() => {
    const currentElements = sectionRef.current;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
          }
        });
      },
      {
        threshold: 0.1,
      }
    );

    currentElements.forEach((element, index) => {
      if (element) {
        element.style.transitionDelay = `${index * 0.04}s`;
        observer.observe(element);
      }
    });

    return () => {
      currentElements.forEach((element) => {
        if (element) {
          observer.unobserve(element);
        }
      });
    };
  }, [API, sectionRef]);

  return (
    <div>
      <Container style={{ padding: "50px 0" }}>
        <Row>
          {API.map((course, index) => {
            if (course.isCompleted !== false || course.percentLearning > 100)
              return null;
            return (
              <Col xs={12} md={4} key={course.id} style={{ marginTop: "30px" }}>
                <Card
                  ref={(el) => (sectionRef.current[index] = el)}
                  className="element-to-animate"
                  style={{ width: "100%", height: "100%" }}
                >
                  <Link
                    to={`/detail/${course.id}`}
                    style={{ textAlign: "center" }}
                  >
                    <Card.Img
                      variant="top"
                      src={course.courseImage}
                      style={{
                        height: "150px",
                        width: "auto",
                        objectFit: "cover",
                      }}
                    />
                  </Link>
                  <Card.Body>
                    <Card.Title>{course.courseName}</Card.Title>
                    <Card.Text>Percent: {course.percentLearning}</Card.Text>
                    <Card.Text>Type: {course.courseType}</Card.Text>
                    <Link to={`/detail/${course.id}`}>
                      <Button variant="primary" className="btn-main-style">
                        View Details
                      </Button>
                    </Link>
                  </Card.Body>
                </Card>
              </Col>
            );
          })}
        </Row>
      </Container>
    </div>
  );
}
