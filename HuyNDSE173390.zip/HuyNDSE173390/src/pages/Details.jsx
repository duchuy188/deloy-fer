import { Link, useParams } from "react-router-dom";
import { MainAPI } from "../MainAPI";
import { useEffect, useState } from "react";
import { Button, Col, Container, Image, Row } from "react-bootstrap";

export default function Detail() {
  const { id } = useParams();
  const baseURL = `${MainAPI}/${id}`;
  const [API, setAPI] = useState({});

  useEffect(() => {
    const fetchAPI = async () => {
      await fetch(baseURL, {
        method: "GET",
        headers: {
          "Content-type": "application/json",
        },
      })
        .then((response) => {
          if (!response.ok) throw new Error("Network response was not ok");
          return response.json();
        })
        .then((data) => setAPI(data))
        .catch((error) => console.log(error));
    };

    fetchAPI();
  }, [baseURL]);

  return (
    <div
      style={{
        height: "calc(100vh - 56px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Container>
        <div
          style={{
            border: "1px solid #d4d4d4",
            borderRadius: "15px",
            padding: "20px",
            height: "453px",
            position: "relative",
          }}
        >
          {API.isCompleted && (
            <div className="ribbon ribbon-top-left">
              <span>Completed</span>
            </div>
          )}
          <Row style={{ height: "100%" }}>
            <Col xs={12} md={6} style={{ height: "100%", textAlign: "center" }}>
              <Image
                variant="top"
                src={API.courseImage}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "contain",
                  borderRadius: "15px",
                }}
              />
            </Col>
            <Col xs={12} md={6}>
              <h1 style={{ fontWeight: "bold" }}>{API.courseName}</h1>
              <p>
                <span style={{ fontWeight: "bold" }}>Percent:</span>{" "}
                {API.percentLearning}
              </p>
              <p>
                <span style={{ fontWeight: "bold" }}>Tyle:</span>{" "}
                {API.courseType}
              </p>
              <Link to={"/"} style={{ textDecoration: "none" }}>
                <Button
                  variant="primary"
                  className="btn-main-style"
                  style={{ width: "initial", marginBottom: "20px" }}
                >
                  Back to Home page
                </Button>
              </Link>
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
}
