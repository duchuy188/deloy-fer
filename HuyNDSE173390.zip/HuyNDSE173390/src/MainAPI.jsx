export const MainAPI =
  "https://66fb9b2f8583ac93b40c6581.mockapi.io/HuyNDSE173390";
