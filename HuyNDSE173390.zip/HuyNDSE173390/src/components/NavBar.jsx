import { Container, Nav, Navbar } from "react-bootstrap";
import { Link } from "react-router-dom";

export default function NavBar() {
  return (
    <Navbar
      expand="lg"
      className="bg-body-tertiary w-100"
      style={{
        cssText: "background-color: #151514 !important",
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
      }}
    >
      <Container fluid>
        <Link
          to={"/"}
          style={{
            padding: "5px 0",
            color: "#fff",
            fontWeight: "bold",
            textDecoration: "none",
            fontSize: "1.4rem",
            marginRight: "10px",
          }}
        >
          Course
        </Link>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Link
              to={"/"}
              style={{
                color: "#fff",
                textDecoration: "none",
                padding: "8px",
              }}
            >
              Home
            </Link>
            <Link
              to={"/HuyNDSE173390"}
              style={{
                color: "#fff",
                textDecoration: "none",
                padding: "8px",
              }}
            >
              All Course
            </Link>
            <Link
              to={"/completed"}
              style={{
                color: "#fff",
                textDecoration: "none",
                padding: "8px",
              }}
            >
              Completed
            </Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
